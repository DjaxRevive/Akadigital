<?php

$cache_contents   = array (
  'cache_contents' => 
  array (
    'url_safe' => true,
  ),
  'cache_ReTry_count' => 1,
  'cache_API_time' => 1578478446,
  'cache_name' => 'brandsafety^https://tuoitre.vn/nuoc-bien-gan-khu-kinh-te-dung-quat-den-noi-bot-vang-bat-thuong-20191204145400213.htm3@182.72.85.22',
  'cache_time' => 1578478053,
);

$cache_complete   = true;

?>