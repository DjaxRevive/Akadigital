<?php

$cache_contents   = array (
  'cache_contents' => 
  array (
    'url_safe' => false,
  ),
  'cache_ReTry_count' => 0,
  'cache_API_time' => 1578478776,
  'cache_name' => 'brandsafety^http://182.72.85.22/3@182.72.85.22',
  'cache_time' => 1578478776,
);

$cache_complete   = true;

?>