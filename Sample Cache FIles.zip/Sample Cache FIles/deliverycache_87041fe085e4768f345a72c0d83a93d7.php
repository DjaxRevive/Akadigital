<?php

$cache_contents   = array (
  'cache_contents' => 
  array (
    'url_safe' => true,
  ),
  'cache_ReTry_count' => 0,
  'cache_API_time' => 1578478606,
  'cache_name' => 'brandsafety^https://www.w3schools.com/js/js_json_parse.asp3@182.72.85.22',
  'cache_time' => 1578478606,
);

$cache_complete   = true;

?>