<?php

$cache_contents   = array (
  'cache_contents' => 
  array (
    'url_safe' => true,
  ),
  'cache_ReTry_count' => 0,
  'cache_API_time' => 1578478551,
  'cache_name' => 'brandsafety^https://www.tutorialspoint.com/php/index.htm3@182.72.85.22',
  'cache_time' => 1578478551,
);

$cache_complete   = true;

?>